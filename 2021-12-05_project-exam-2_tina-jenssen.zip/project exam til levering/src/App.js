import "./sass/style.scss";
import React from "react";
import Container from "react-bootstrap/Container";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from "./components/home/Home";
import Contact from "./components/contact/Contact";
import Login from "./components/login/Login";
import Places from "./components/places/PlacesToStay";
import PlaceDetails from "./components/places/PlaceDetails";
import Admin from "./components/admin/Admin";
import Navigation from "./components/layout/Navigation.jsx";
import { AuthProvider } from "./components/context/AuthContext";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navigation />
        <Container>
          <Switch>
            <Route path="/" exact component={Home} />
            <Route path="/contact" component={Contact} />
            <Route path="/places-to-stay" component={Places} />
            <Route path="/login" component={Login} />
            <Route path="/detail/:id" component={PlaceDetails} />
            <Route path="/admin" exact component={Admin} />
          </Switch>
        </Container>
      </Router>
    </AuthProvider>
  );
}

export default App;
