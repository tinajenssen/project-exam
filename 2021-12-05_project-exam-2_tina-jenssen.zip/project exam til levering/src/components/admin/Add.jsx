import { useState } from "react";
import Button from "react-bootstrap/button";
import Modal from "react-bootstrap/modal";

export default function AddNew() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button className="add-btn" onClick={handleShow}>
        Add new place
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton></Modal.Header>
        <Modal.Body>
          <fieldset>
            <form className="add-new">
              <h1>Add new place</h1>
              <p>Name</p>
              <input />
              <p>Distance from centre</p>
              <input />
              <p>Price</p>
              <input />
              <p>Rating</p>
              <input />
              <p>Description</p>
              <textarea />
              <button className="btn">Add</button>
            </form>
          </fieldset>
        </Modal.Body>
      </Modal>
    </>
  );
}
