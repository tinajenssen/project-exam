import Container from "react-bootstrap/Container";
import Heading from "../layout/Heading";
import Breadcrumb from "react-bootstrap/breadcrumb";
import AddNew from "./Add";
import AdminTable from "./Table";

export default function AdminPage() {
  return (
    <>
      <Container fluid="md" className="content-container">
        <Breadcrumb>
          <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
          <Breadcrumb.Item active>Admin</Breadcrumb.Item>
        </Breadcrumb>
        <Heading title="Admin" />
        <AddNew />
        <AdminTable />
      </Container>
    </>
  );
}
