import Table from "react-bootstrap/Table";

export default function AdminTable() {
  return (
    <>
      <div className="requests">
        <h2>Requests</h2>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Request to</th>
              <th>Date from</th>
              <th>Date to</th>
              <th>Number of guests</th>
            </tr>
          </thead>
          {/* <tbody>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody> */}
        </Table>
      </div>

      <div className="messages">
        <h2>Messages</h2>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Message</th>
            </tr>
          </thead>
          {/* <tbody>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody> */}
        </Table>
      </div>
    </>
  );
}
