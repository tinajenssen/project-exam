import Heading from "../layout/Heading";
import ContactForm from "./ContactForm";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Breadcrumb from "react-bootstrap/breadcrumb";
import Footer from "../layout/Footer";

export default function Contact() {
  return (
    <>
      <Container fluid="md" className="content-container">
        <Breadcrumb>
          <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
          <Breadcrumb.Item active>Contact</Breadcrumb.Item>
        </Breadcrumb>
        <Container className="form-container">
          <Row>
            <Col sm={4}>
              <div className="contact-info">
                <p>Get in touch with us!</p>
                <p>
                  {" "}
                  We are happy to answer any questions you may have. Enter your
                  details and send us a message and we'll get back to you
                  shortly.
                </p>
              </div>
            </Col>
            <Col sm={8}>
              <Heading title="Contact" />
              <ContactForm />
            </Col>
          </Row>
        </Container>
        <Footer />
      </Container>
    </>
  );
}
