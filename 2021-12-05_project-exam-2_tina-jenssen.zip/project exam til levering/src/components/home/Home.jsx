import Jumbotron from "./Jumbotron";
import Footer from "../layout/Footer";

export default function Home() {
  return (
    <>
      <Jumbotron />
      <Footer />
    </>
  );
}
