import Jumbotron from "react-bootstrap/jumbotron";
import bryggen from "../../img/bryggen.jpg";

export default function HomePageJumbotron() {
  return (
    <Jumbotron>
      <img src={bryggen} className="jumbotron-img" alt="logo" />
    </Jumbotron>
  );
}
