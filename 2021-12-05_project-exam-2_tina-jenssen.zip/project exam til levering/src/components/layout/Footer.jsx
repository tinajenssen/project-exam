import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import logo from "../../img/logo.png";
import facebook from "../../img/facebook.png";
import twitter from "../../img/twitter.png";
import instagram from "../../img/instagram.png";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <div className="footer">
        <Container fluid="md" className="content-container">
          <Row className="footer-content">
            <Col sm>
              <Link to="/">
                <img src={logo} className="logo" alt="logo" />
              </Link>
            </Col>
            <Col sm>
              <p>© Copyright Holidaze 2021</p>
            </Col>
            <Col sm>
              <Link to="#">
                <img src={facebook} className="some" alt="facebook" />
              </Link>
              <Link to="#">
                <img src={twitter} className="some" alt="twitter" />
              </Link>
              <Link to="#">
                <img src={instagram} className="some" alt="instagram" />
              </Link>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}
