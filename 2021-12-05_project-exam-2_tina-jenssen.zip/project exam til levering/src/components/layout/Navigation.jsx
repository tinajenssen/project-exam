import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import { Link, useHistory } from "react-router-dom";
import Container from "react-bootstrap/Container";
import logo from "../../img/logo.png";
import { useContext } from "react";
import AuthContext from "../context/AuthContext";

function Navigation() {
  const [auth, setAuth] = useContext(AuthContext);

  const history = useHistory;

  function logout() {
    setAuth(null);
    history.push("/");
  }

  return (
    <Navbar collapseOnSelect expand="lg">
      <Container fluid="md" className="content-container">
        <Navbar.Brand className="d-lg-none" href="/">
          <img src={logo} className="logo" alt="logo" />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="nav-left">
            <Link to="/places-to-stay" className="nav-link">
              Places to stay
            </Link>
            <Link to="/contact" className="nav-link">
              Contact
            </Link>
          </Nav>

          <Navbar.Brand
            className="d-none d-lg-flex justify-content-center"
            href="/"
          >
            <img src={logo} className="logo" alt="logo" />
          </Navbar.Brand>
          <Nav className="nav-right">
            {auth ? (
              <>
                <button onClick={logout} className="nav-btn">
                  Log out
                </button>
              </>
            ) : (
              <Link to="/login" className="login">
                Login
              </Link>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Navigation;
