import LoginForm from "./LoginForm";
import Breadcrumb from "react-bootstrap/breadcrumb";
import Container from "react-bootstrap/Container";
import Footer from "../layout/Footer";

export default function Login() {
  return (
    <>
      <Container fluid="md" className="content-container">
        <Breadcrumb>
          <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
          <Breadcrumb.Item active>Login</Breadcrumb.Item>
        </Breadcrumb>
        <LoginForm />
        <Footer />
      </Container>
    </>
  );
}
