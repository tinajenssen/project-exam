import { useState, useEffect } from "react";
import PlaceCard from "./PlaceCard";
import { API } from "../../constants/strapiApi";
import Loading from "../common/Loading";

function ListOfPlaces() {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(function () {
    async function fecthData() {
      try {
        const response = await fetch(API);

        if (response.ok) {
          const json = await response.json();
          console.log(json);
          setPlaces(json);
        } else {
          setError("An error occured");
        }
      } catch (error) {
        setError(error.toString());
      } finally {
        setLoading(false);
      }
    }
    fecthData();
  }, []);

  if (loading) {
    return <Loading />;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="places">
      {places.map(function (places) {
        const { id, name, price, rating, distance } = places;

        return (
          <PlaceCard
            key={id}
            id={id}
            name={name}
            price={price}
            rating={rating}
            distance={distance}
          />
        );
      })}
    </div>
  );
}

export default ListOfPlaces;

//PlaceCard
//url={img[0].url}
