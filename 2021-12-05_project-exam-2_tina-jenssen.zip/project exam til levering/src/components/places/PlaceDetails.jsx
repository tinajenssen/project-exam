import { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import { API } from "../../constants/strapiApi";
import Loading from "../common/Loading";
import Container from "react-bootstrap/Container";
import Breadcrumb from "react-bootstrap/Breadcrumb";
import star from "../../img/star.png";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Request from "./Request";
import Footer from "../layout/Footer";

function PlaceDetail() {
  const [place, setPlace] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  let history = useHistory();

  const { id } = useParams();

  if (!id) {
    history.push("/");
  }

  const url = API + "/" + id;

  useEffect(
    function () {
      async function fecthData() {
        try {
          const response = await fetch(url);

          if (response.ok) {
            const json = await response.json();
            console.log(json);
            setPlace(json);
          } else {
            setError("An error occured");
          }
        } catch (error) {
          setError(error.toString());
        } finally {
          setLoading(false);
        }
      }
      fecthData();
    },
    [url]
  );

  if (loading) {
    return (
      <div>
        <Loading />
      </div>
    );
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <>
      <Container fluid="md" className="content-container">
        <Breadcrumb>
          <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
          <Breadcrumb.Item href="/places-to-stay">
            Places to stay
          </Breadcrumb.Item>
          <Breadcrumb.Item active>{place.name}</Breadcrumb.Item>
        </Breadcrumb>
        <Row>
          <Col className="col-left"></Col>
          <Col className="col-right">
            <div className="place-detail">
              <div className="name">{place.name}</div>
              <div className="distance">{place.distance} km from centre</div>

              <div className="test">
                <div className="price">Starting from {place.price} NOK</div>
                <div className="rating">
                  <img src={star} className="star" alt="logo" />
                  {place.rating}
                </div>
              </div>
              <div className="description">{place.description}</div>
              <Request />
            </div>
          </Col>
        </Row>
      </Container>
      <Footer />
    </>
  );
}

export default PlaceDetail;
