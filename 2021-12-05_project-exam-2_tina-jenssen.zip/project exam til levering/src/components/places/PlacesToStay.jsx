import Heading from "../layout/Heading";
import Footer from "../layout/Footer";
import ListOfPlaces from "../places/ListOfPlaces";
import Container from "react-bootstrap/Container";
import Breadcrumb from "react-bootstrap/breadcrumb";

export default function Places() {
  return (
    <>
      <Container fluid="md" className="content-container">
        <Breadcrumb>
          <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
          <Breadcrumb.Item active>Places to stay</Breadcrumb.Item>
        </Breadcrumb>

        <Heading title="Places to stay" />
        <h2>Find the perfect place to stay at when visiting Bergen</h2>

        <ListOfPlaces />
      </Container>
      <Footer />
    </>
  );
}
