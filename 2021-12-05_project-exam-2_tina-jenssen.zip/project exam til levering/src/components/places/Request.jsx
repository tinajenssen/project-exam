import { useState } from "react";
import Button from "react-bootstrap/button";
import Modal from "react-bootstrap/modal";

export default function Request() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button className="modal-btn" onClick={handleShow}>
        Send request
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton></Modal.Header>
        <Modal.Body>
          <fieldset>
            <form className="send-request">
              <h1>Send request</h1>
              <input placeholder="Name" />
              <input placeholder="Date from" />
              <input placeholder="Date to" />
              <input placeholder="Guests" />

              <button className="btn">Send</button>
            </form>
          </fieldset>
        </Modal.Body>
      </Modal>
    </>
  );
}
